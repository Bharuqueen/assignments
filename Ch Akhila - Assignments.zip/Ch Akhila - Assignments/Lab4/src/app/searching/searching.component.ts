import { Component, OnInit } from '@angular/core';
import { BookDetailsService } from '../book-details.service';
import { IBookList } from '../ibook-list';

@Component({
  selector: 'app-searching',
  templateUrl: './searching.component.html',
  styleUrls: ['./searching.component.css']
})
export class SearchingComponent implements OnInit {

  BookList: IBookList[];

  constructor(private _bookService: BookDetailsService) { }

  ngOnInit() {
    this._bookService.getBooks()
        .subscribe(data => this.BookList = data);

        console.log(this.BookList);
  }

  sclick(){
    
  }

}
